import type { AppLocale } from './types'
import { store } from '@/storage'
import { isAppLocale, LOCALE_STORAGE_KEY, SUPPORTED_LOCALES } from './constants'

function normalizeLocale(value: string | null | undefined): AppLocale | null {
  if (!value)
    return null

  if (isAppLocale(value))
    return value

  const lower = value.toLowerCase()

  if (lower.startsWith(`pt`))
    return `pt-BR`

  if (lower === `zh-tw` || lower === `zh-hk` || lower === `zh-mo` || lower.startsWith(`zh-hant`))
    return `zh-TW`

  if (lower.startsWith(`zh`))
    return `zh-CN`

  if (lower.startsWith(`ja`))
    return `ja-JP`

  if (lower.startsWith(`en`))
    return `en-US`

  return null
}

export function detectInitialLocale(): AppLocale {
  const stored = store.getSync(LOCALE_STORAGE_KEY)
  const fromStorage = normalizeLocale(stored)
  if (fromStorage && SUPPORTED_LOCALES.includes(fromStorage))
    return fromStorage

  if (typeof window !== `undefined`) {
    const bootLocale = normalizeLocale(
      (window as Window & { __MD_BOOT_LOCALE__?: string }).__MD_BOOT_LOCALE__,
    )
    if (bootLocale && SUPPORTED_LOCALES.includes(bootLocale))
      return bootLocale
  }

  return `pt-BR`
}
