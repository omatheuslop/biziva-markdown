export type AppLocale = `zh-CN` | `zh-TW` | `en-US` | `ja-JP` | `pt-BR`

export interface LocaleOption {
  value: AppLocale
  labelKey: `locale.zhCN` | `locale.zhTW` | `locale.enUS` | `locale.jaJP` | `locale.ptBR`
  shortLabel: string
}
