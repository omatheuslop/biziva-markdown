// Biziva Brazilian Portuguese locale; original keys and placeholders preserved.
export default {
  "share": {
    "title": "Compartilhar pré-visualização",
    "description": "Gere um link somente leitura que corresponde à pré-visualização do editor para compartilhar facilmente.",
    "notConfiguredTitle": "Serviço de compartilhamento não configurado",
    "notConfiguredDescription": "Esta implantação não tem serviço de compartilhamento configurado. Contate o operador para habilitá-lo.",
    "loginTitle": "Faça login para compartilhar a pré-visualização",
    "tabCreate": "Criar compartilhamento",
    "tabManage": "Meus compartilhamentos",
    "expiresIn1Day": "Expira em 1 dia",
    "limitPerDay": "2 por dia",
    "expiresLabel": "Validade do link",
    "expiresMode": {
      "1d": "1 dia",
      "7d": "7 dias",
      "30d": "30 dias",
      "never": "Nunca expira"
    },
    "passwordLabel": "Senha de acesso",
    "passwordMode": {
      "public": {
        "label": "Link público",
        "description": "Qualquer pessoa com o link pode visualizar"
      },
      "custom": {
        "label": "Senha personalizada",
        "description": "Defina uma senha de acesso de 4 a 64 caracteres"
      },
      "auto": {
        "label": "Senha aleatória",
        "description": "O sistema gera uma senha de 8 caracteres após a criação"
      }
    },
    "customPasswordLabel": "Digite a senha de acesso",
    "customPasswordPlaceholder": "4 a 64 caracteres",
    "generateLink": "Gerar link de compartilhamento",
    "generating": "Gerando…",
    "stageRendering": "Aguardando a renderização de gráficos e fórmulas…",
    "stageUploading": "Enviando pré-visualização do compartilhamento…",
    "readyHint": "O link de compartilhamento está pronto. Copie-o ou abra a pré-visualização.",
    "linkLabel": "Link de compartilhamento",
    "accessPasswordLabel": "Senha de acesso",
    "copyLinkAndPassword": "Copiar link e senha",
    "customPasswordHint": "A proteção por senha está habilitada. Guarde sua senha em local seguro.",
    "expiresAt": "Expira em: {date}",
    "previewConsistent": "Corresponde à pré-visualização do editor",
    "regenerate": "Redefinir e gerar novamente",
    "manageHint": "Gerencie os links de compartilhamento publicados. Revogar um link tem efeito imediato.",
    "refreshList": "Atualizar lista",
    "emptyTitle": "Nenhum compartilhamento ainda",
    "emptyDescription": "Após criar um compartilhamento, gerencie os links aqui.",
    "viewCount": "{count} visualizações",
    "expired": "Expirado",
    "permanent": "Nunca expira",
    "expiresOn": "Expira em {date}",
    "passwordProtected": "Protegido por senha",
    "copyLink": "Copiar link",
    "copyPassword": "Copiar senha",
    "openPreview": "Abrir pré-visualização",
    "revokeShare": "Revogar compartilhamento",
    "untitled": "Sem título",
    "proRequired": "Meus compartilhamentos é um recurso exclusivo do Pro",
    "loadListFailed": "Falha ao carregar compartilhamentos: {message}",
    "revokeTitle": "Revogar compartilhamento",
    "revokeDescription": "Revogar o compartilhamento de \"{title}\"? O link deixará de funcionar imediatamente.",
    "revokeSuccess": "Compartilhamento revogado",
    "revokeFailed": "Falha ao revogar compartilhamento: {message}",
    "invalidPost": "O post atual é inválido. Atualize e tente novamente.",
    "linkUpdated": "Link de compartilhamento atualizado",
    "linkCreated": "Link de compartilhamento criado",
    "createFailed": "Falha ao criar link de compartilhamento: {message}",
    "invalidPassword": "A senha deve ter de 4 a 64 caracteres.",
    "forbidden": "Você não pode atualizar este compartilhamento. Atualize e tente novamente.",
    "rateLimited": "Até {limit} compartilhamentos por dia",
    "rateLimitedGeneric": "Compartilhando com muita frequência",
    "retryAfterHours": ". Tente novamente em {hours} hora(s)",
    "retryAfterMinutes": ". Tente novamente em {minutes} minuto(s)",
    "retryTomorrow": ". Tente novamente amanhã",
    "copyBundle": {
      "link": "Link: {url}",
      "password": "Senha: {password}"
    }
  },
  "sync": {
    "title": "Sincronização na nuvem",
    "description": "Sincronize posts e configurações entre dispositivos. Chaves e credenciais de hospedagem de imagens não são incluídas.",
    "notConfiguredTitle": "Sincronização na nuvem desativada",
    "notConfiguredDescription": "Esta implantação não tem serviço de sincronização configurado. Contate o operador para habilitá-lo.",
    "loginTitle": "Faça login para habilitar a sincronização na nuvem",
    "lastSync": "Última sincronização: {time}",
    "neverSynced": "Nunca sincronizado",
    "syncNow": "Sincronizar agora",
    "syncing": "Sincronizando…",
    "syncFailed": "Falha na sincronização: {message}",
    "syncSuccess": "Sincronização concluída"
  },
  "account": {
    "title": "Conta",
    "loginHint": "Faça login para usar a sincronização na nuvem, a pré-visualização de compartilhamento e outros recursos na nuvem.",
    "notConfiguredTitle": "Serviço de conta não configurado",
    "notConfiguredDescription": "O operador deve definir VITE_MD_API_URL antes do login e da sincronização na nuvem.",
    "loginTitle": "Faça login na sua conta",
    "githubLogin": "Fazer login com GitHub",
    "extensionLoginUnavailable": "O login na extensão não está disponível. Atualize a extensão ou use o aplicativo web.",
    "loginFailed": "Falha no login. Tente novamente mais tarde.",
    "loginCancelled": "Login cancelado",
    "loggingIn": "Fazendo login…",
    "cloudSync": "Sincronização na nuvem",
    "sharePreview": "Compartilhar pré-visualização"
  },
  "about": {
    "title": "Sobre",
    "description": "Um editor Markdown minimalista para contas oficiais do WeChat",
    "followHint": "Escaneie o QR code para seguir o Doocs no WeChat e ver conteúdo técnico original.",
    "imageAlt": "Editor Markdown Doocs"
  },
  "fund": {
    "title": "Apoie-nos",
    "description": "Se você gosta deste projeto, pode nos apoiar das seguintes formas.",
    "qrAlt1": "QR code de apoio 1",
    "qrAlt2": "QR code de apoio 2"
  },
  "markdownHelp": {
    "title": "Ajuda de sintaxe Markdown",
    "description": "Navegue pela sintaxe Markdown compatível. Clique em um item para copiá-lo.",
    "clickToCopy": "Clique para copiar",
    "tabs": {
      "basic": "Básico",
      "code": "Blocos de código",
      "math": "Matemática",
      "diagram": "Diagramas",
      "other": "Outros"
    },
    "syntax": {
      "basic": [
        {
          "name": "Título",
          "syntax": "# Título 1\n## Título 2\n### Título 3",
          "tip": "Use a quantidade de # para o nível, até seis níveis"
        },
        {
          "name": "Negrito",
          "syntax": "**texto em negrito**",
          "example": "texto em negrito"
        },
        {
          "name": "Itálico",
          "syntax": "*texto em itálico*",
          "example": "texto em itálico"
        },
        {
          "name": "Riscado",
          "syntax": "~~texto riscado~~",
          "example": "texto riscado"
        },
        {
          "name": "Destaque",
          "syntax": "==texto destacado==",
          "example": "texto destacado"
        },
        {
          "name": "Sublinhado",
          "syntax": "++texto sublinhado++",
          "example": "texto sublinhado"
        },
        {
          "name": "Sobrescrito",
          "syntax": "x^2^",
          "example": "x²",
          "tip": "Escreva logo após o texto; o conteúdo não pode conter espaços"
        },
        {
          "name": "Código embutido",
          "syntax": "`código`",
          "example": "código"
        },
        {
          "name": "Lista não ordenada",
          "syntax": "- Item 1\n- Item 2\n  - Subitem",
          "tip": "Use -, * ou + seguidos de espaço"
        },
        {
          "name": "Lista ordenada",
          "syntax": "1. Item 1\n2. Item 2",
          "tip": "Número seguido de ponto"
        },
        {
          "name": "Link",
          "syntax": "[texto exibido](url)",
          "example": "Doocs",
          "tip": "Contas Oficiais do WeChat não suportam links externos"
        },
        {
          "name": "Imagem",
          "syntax": "![texto alternativo](url-da-imagem)",
          "tip": "Suporta URLs de imagens remotas"
        },
        {
          "name": "Citação",
          "syntax": "> texto citado\n>> citação aninhada"
        },
        {
          "name": "Linha horizontal",
          "syntax": "---",
          "tip": "Três ou mais -, * ou _"
        },
        {
          "name": "Tabela",
          "syntax": "| Col 1 | Col 2 |\n| --- | --- |\n| Valor 1 | Valor 2 |",
          "tip": "Use Editar > Inserir tabela para criar rápido"
        }
      ],
      "code": [
        {
          "name": "Bloco de código básico",
          "syntax": "```\nconteúdo do código\n```"
        },
        {
          "name": "Específico por linguagem",
          "syntax": "```js\nconsole.log(\"Hello\")\n```",
          "tip": "Suporta js, ts, python, java, go e mais"
        }
      ],
      "math": [
        {
          "name": "Fórmula em linha",
          "syntax": "$E = mc^2$",
          "example": "E = mc²"
        },
        {
          "name": "Fórmula em bloco",
          "syntax": "$$\n\\int_0^1 x^2 dx\n$$"
        },
        {
          "name": "LaTeX (em linha)",
          "syntax": "\\(x^2 + y^2\\)",
          "tip": "Formato padrão LaTeX"
        },
        {
          "name": "LaTeX (em bloco)",
          "syntax": "\\[\n\\sum_{i=1}^n x_i\n\\]"
        }
      ],
      "diagram": [
        {
          "name": "Fluxograma Mermaid",
          "syntax": "```mermaid\ngraph LR\n  A --> B\n```",
          "tip": "Suporta fluxogramas, diagramas de sequência, gráficos de pizza e mais"
        },
        {
          "name": "PlantUML",
          "syntax": "```plantuml\n@startuml\nA -> B\n@enduml\n```",
          "tip": "Veja em plantuml.com"
        },
        {
          "name": "Infográfico",
          "syntax": "```infographic\ninfographic list-row\n...\n```",
          "tip": "Engine de infográficos AntV"
        }
      ],
      "other": [
        {
          "name": "Emoji",
          "syntax": ":foguete: :tada: :+1:",
          "example": "🚀 🎉 👍",
          "tip": "Shortcodes do GitHub; nomes não incluídos são exibidos como texto comum"
        },
        {
          "name": "Figurinha",
          "syntax": "<Emoji id=\"liulei\" />\n<Emoji id=\"liulei\" width=\"20%\" />\n<Emoji id=\"liulei\" width=\"20%\" align=\"center\" />",
          "tip": "Componente embutido; align só funciona em linha própria"
        },
        {
          "name": "Anotação ruby",
          "syntax": "[texto]{ruby}\n[texto]^(ruby)",
          "example": "olá",
          "tip": "Suporta kana, pinyin e mais"
        },
        {
          "name": "Apresentação de slides",
          "syntax": "<![alt](url1),![alt](url2)>",
          "tip": "Imagens em carrossel, apenas para Contas Oficiais do WeChat"
        },
        {
          "name": "Tags HTML",
          "syntax": "<center>conteúdo centralizado</center>",
          "tip": "Algumas tags HTML são suportadas"
        }
      ]
    }
  },
  "postInfo": {
    "publish": "Publicar",
    "title": "Publicar",
    "description": "Publicar seu artigo em várias plataformas",
    "extensionMissingTitle": "Extensão não detectada",
    "extensionMissingDescription": "Instale a extensão {link} do navegador",
    "extensionLinkText": "Assistente de Sincronização de Artigos COSE",
    "coseHint": "Desenvolvido por {githubLink}. Funciona totalmente local e não coleta nem armazena dados do usuário.",
    "coseGithubText": "o plugin de código aberto COSE no GitHub",
    "coseContribute": "Para adicionar plataformas ou melhorar a precisão da sincronização, abra uma {issueLink} ou um PR.",
    "issueLinkText": "Issue",
    "cover": "Capa",
    "coverPlaceholder": "Extrair automaticamente a primeira imagem",
    "titleLabel": "Título",
    "titlePlaceholder": "Extrair automaticamente o primeiro título",
    "descLabel": "Resumo",
    "descPlaceholder": "Extrair automaticamente o primeiro parágrafo",
    "platform": "Plataformas",
    "selectAll": "Selecionar tudo",
    "checking": "Verificando",
    "coverPreview": "Pré-visualização da capa",
    "coverPreviewAlt": "Pré-visualização da capa",
    "categories": {
      "media": "Mídia",
      "blog": "Blog",
      "cloud": "Nuvem e desenvolvimento"
    }
  },
  "postTask": {
    "title": "Enviar tarefa de publicação",
    "waiting": "Aguardando publicação…",
    "publishing": "Publicando",
    "syncFailed": "Falha na sincronização: {error}",
    "syncSuccess": "Sincronização concluída com sucesso",
    "viewDraft": "Ver rascunho"
  },
  "preferences": {
    "title": "Preferências",
    "description": "Personalize idioma, aparência e comportamento do editor.",
    "tab": {
      "general": "Geral",
      "editor": "Editor",
      "preview": "Visualizar"
    },
    "language": {
      "label": "Idioma",
      "hint": "Idioma da interface"
    },
    "darkMode": {
      "label": "Modo escuro"
    },
    "viewMode": {
      "label": "Modo de visualização"
    },
    "viewModeOption": {
      "edit": "Editar",
      "split": "Dividir",
      "preview": "Visualizar"
    },
    "previewDevice": {
      "label": "Dispositivo de pré-visualização"
    },
    "previewDeviceOption": {
      "desktop": "Desktop",
      "mobile": "Celular"
    },
    "scrollSync": {
      "label": "Sincronização de rolagem",
      "hint": "Sincronizar a rolagem do editor e da pré-visualização"
    },
    "showAIToolbox": {
      "label": "Barra de ferramentas de IA",
      "hint": "Exibir o assistente de IA, o gerador de imagens e a barra de ferramentas na borda do editor"
    },
    "imageReupload": {
      "label": "Reenvio de imagens",
      "hint": "Reenviar imagens para o seu serviço de hospedagem de imagens ao copiar"
    },
    "wordCount": {
      "label": "Contagem de palavras",
      "hint": "Exibir contagem de palavras e tempo de leitura no topo da pré-visualização"
    }
  },
  "pdfExport": {
    "title": "Exportar PDF",
    "description": "Configure cabeçalhos, rodapés e layout, depois salve como PDF pelo diálogo de impressão do navegador. Os espaços desativados são preenchidos com strings vazias para que o navegador não insira seus padrões.",
    "pageNumbers": {
      "label": "Números de página",
      "hint": "Exibir números de página no rodapé"
    },
    "pageNumberFormat": {
      "label": "Formato do número de página",
      "nOfM": "Página N de M",
      "n": "Apenas número de página"
    },
    "pageNumberPosition": {
      "label": "Posição do número de página",
      "bottomLeft": "Inferior esquerdo",
      "bottomCenter": "Inferior central",
      "bottomRight": "Inferior direito"
    },
    "titleHeader": {
      "label": "Cabeçalho do título",
      "hint": "Exibir o título do artigo no cabeçalho"
    },
    "siteFooter": {
      "label": "Rodapé do site",
      "hint": "Exibir {url} no rodapé"
    },
    "margins": {
      "label": "Margens",
      "compact": "Compacto",
      "default": "Padrão",
      "comfortable": "Confortável"
    },
    "export": "Imprimir / Salvar como PDF"
  }
}
