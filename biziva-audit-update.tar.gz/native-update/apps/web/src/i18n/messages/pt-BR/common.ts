// Biziva Brazilian Portuguese locale; original keys and placeholders preserved.
export default {
  "locale": {
    "label": "Idioma",
    "zhCN": "简体中文",
    "zhTW": "繁體中文",
    "enUS": "English",
    "jaJP": "日本語",
    "ptBR": "Português (Brasil)"
  },
  "meta": {
    "title": "Biziva Documentos | Baseado no Doocs",
    "description": "Editor Markdown do WeChat | Um editor Markdown minimalista para contas oficiais do WeChat"
  },
  "loader": {
    "tagline": "Tornando a edição em Markdown mais simples",
    "loading": "Carregando editor",
    "timeout": "O carregamento está demorando muito. Tente atualizar a página ou pressione F12 para verificar erros no console."
  },
  "common": {
    "tip": "Aviso",
    "cancel": "Cancelar",
    "confirm": "Confirmar",
    "save": "Salvar",
    "create": "Novo",
    "edit": "Editar",
    "delete": "Excluir",
    "close": "Fechar",
    "more": "Mais",
    "copy": "Copiar",
    "reset": "Redefinir",
    "clear": "Limpar",
    "loading": "Carregando...",
    "login": "Entrar",
    "logout": "Sair",
    "search": "Buscar",
    "export": "Exportar",
    "import": "Importar",
    "apply": "Aplicar",
    "done": "Concluído",
    "skip": "Pular",
    "retry": "Tentar novamente",
    "refresh": "Atualizar",
    "unnamed": "Sem título",
    "unknown": "Desconhecido",
    "copied": "Copiado",
    "copyFailed": "Falha ao copiar. Copie manualmente.",
    "copiedToClipboard": "Copiado para a área de transferência",
    "saveSuccess": "Salvo com sucesso",
    "deleteSuccess": "Excluído com sucesso",
    "operationSuccess": "Operação bem-sucedida",
    "operationFailed": "Falha na operação",
    "required": "Obrigatório",
    "optional": "Opcional",
    "noData": "Sem dados",
    "selectAll": "Selecionar tudo",
    "deselectAll": "Desmarcar tudo",
    "selected": "Selecionado",
    "selectPost": "Selecionar \"{title}\"",
    "unit": "itens",
    "yes": "Sim",
    "no": "Não",
    "view": "Exibir",
    "open": "Abrir",
    "insert": "Inserir",
    "download": "Baixar",
    "upload": "Enviar",
    "uploading": "Enviando...",
    "processing": "Processando...",
    "generating": "Gerando...",
    "testing": "Testando...",
    "testConnection": "Testar conexão",
    "lightMode": "Modo claro",
    "darkMode": "Modo escuro",
    "account": "Conta",
    "moreActions": "Mais ações",
    "backToTop": "Voltar ao topo",
    "expand": "Expandir",
    "collapse": "Recolher",
    "accept": "Aceitar",
    "send": "Enviar",
    "pause": "Pausar",
    "add": "Novo",
    "rename": "Renomear",
    "merge": "Mesclar",
    "history": "Histórico",
    "preview": "Visualizar",
    "default": "Padrão",
    "custom": "Personalizado",
    "none": "Nenhum",
    "enabled": "Ativado",
    "disabled": "Desativado"
  },
  "menu": {
    "file": "Arquivo",
    "edit": "Editar",
    "format": "Formatar",
    "insert": "Inserir",
    "style": "Estilo",
    "help": "Ajuda",
    "localFolder": "Pasta",
    "import": "Importar",
    "importMarkdown": "Markdown",
    "export": "Exportar",
    "exportMarkdown": "Markdown",
    "exportHtml": "HTML",
    "exportHtmlNoStyle": "HTML (simples)",
    "exportPdf": "PDF",
    "exportPng": "PNG",
    "exportPngSegments": "PNG (dividido)",
    "exportPngSegmentHeight": "~{height}px por imagem",
    "templateManage": "Modelos",
    "marketplace": "Temas da comunidade",
    "contentManage": "Conteúdo",
    "cloudSync": "Sincronizar",
    "sharePreview": "Compartilhar",
    "preferences": "Preferências",
    "importExportConfig": "Importar/Exportar",
    "emoji": "Inserir emoji",
    "undo": "Desfazer",
    "redo": "Refazer",
    "copy": "Copiar",
    "copyWechat": "WeChat",
    "copyHtml": "HTML",
    "copyHtmlNoStyle": "HTML (simples)",
    "copyHtmlCompat": "HTML (compatível)",
    "copyMd": "Markdown",
    "copySelection": "Seleção",
    "paste": "Colar",
    "formatContent": "Formatar",
    "reset": "Redefinir",
    "clear": "Limpar",
    "find": "Localizar",
    "replace": "Substituir",
    "bold": "Negrito",
    "italic": "Itálico",
    "strikethrough": "Riscado",
    "link": "Link",
    "inlineCode": "Código",
    "textColor": "Cor",
    "heading": "Título",
    "headingN": "H{n}",
    "unorderedList": "Lista com marcadores",
    "orderedList": "Lista numerada",
    "wechatLinkToCite": "Link → citação",
    "wordCountTime": "Estatísticas",
    "image": "Imagem",
    "formula": "Fórmula",
    "table": "Tabela",
    "component": "Componente",
    "theme": "Tema",
    "font": "Fonte",
    "fontSize": "Tamanho",
    "lineHeight": "Altura da linha",
    "blockSpacing": "Espaçamento entre blocos",
    "primaryColor": "Cor",
    "linkColor": "Cor do link",
    "blockquoteBackground": "Fundo da citação",
    "codeBlockTheme": "Tema do código",
    "legendFormat": "Legenda",
    "customPrimaryColor": "Cor personalizada",
    "customCss": "CSS personalizado",
    "macCodeBlock": "Estilo Mac",
    "commandPalette": "Comandos",
    "keyboardShortcuts": "Atalhos",
    "syntaxHelp": "Sintaxe",
    "feedback": "Feedback",
    "releaseHistory": "Lançamentos",
    "about": "Sobre",
    "fund": "Apoie-nos"
  },
  "header": {
    "menu": "Menu",
    "copy": "Copiar",
    "style": "Estilo",
    "emoji": "Emoji"
  },
  "toast": {
    "copiedMarkdown": "Código-fonte Markdown copiado para a área de transferência.",
    "copyFailed": "Falha na cópia: {message}",
    "processHtmlFailed": "Falha ao processar o HTML. Entre em contato com o desenvolvedor. {message}",
    "asyncContentPending": "Alguns gráficos ou fórmulas ainda estão sendo renderizados. O conteúdo não carregado foi ignorado. Tente novamente mais tarde.",
    "outputAreaMissing": "Área de cópia de saída não encontrada. Atualize a página e tente novamente.",
    "copyFailedContactDev": "Falha na cópia. Entre em contato com o desenvolvedor. {message}",
    "copiedHtml": "Código-fonte HTML copiado. Continue para a próxima etapa.",
    "copiedRendered": "Conteúdo renderizado copiado para a área de transferência. Você pode colar diretamente no back-end do WeChat.",
    "styleReset": "Estilo redefinido",
    "contentCleared": "Conteúdo limpo",
    "contentReset": "Conteúdo redefinido",
    "pasteFailed": "Falha ao colar. Verifique as permissões da área de transferência. {message}",
    "storageQuota": "O armazenamento local está cheio. Algumas configurações podem não ser salvas."
  },
  "confirm": {
    "tip": "Aviso",
    "resetStyleDescription": "Isso descartará os estilos personalizados locais. Continuar?",
    "deleteItem": "Isso excluirá \"{name}\"",
    "deleteTemplate": "Excluir o modelo \"{name}\"? Isso não pode ser desfeito.",
    "deleteComponent": "Confirmar exclusão",
    "cancelShare": "Cancelar o compartilhamento de \"{title}\"?",
    "restoreVersion": "Isso substituirá o conteúdo atual por esta versão. Continuar?",
    "deleteCssScheme": "Excluir {count} esquema(s) selecionado(s)?"
  },
  "styleOptions": {
    "theme": {
      "default": {
        "label": "Clássico",
        "desc": ""
      },
      "grace": {
        "label": "Grace",
        "desc": "{'@'}brzhang"
      },
      "simple": {
        "label": "Simples",
        "desc": "{'@'}okooo5km"
      }
    },
    "fontFamily": {
      "sansSerif": {
        "label": "Sans",
        "desc": "Font123Abc"
      },
      "serif": {
        "label": "Serif",
        "desc": "Font123Abc"
      },
      "monospace": {
        "label": "Mono",
        "desc": "Font123Abc"
      }
    },
    "fontSize": {
      "smaller": "XS",
      "slightlySmaller": "S",
      "recommended": "M",
      "slightlyLarger": "L",
      "larger": "XL"
    },
    "lineHeight": {
      "tight": "Estreito",
      "slightlyTight": "Levemente estreito",
      "recommended": "Recomendado",
      "slightlyLoose": "Levemente amplo",
      "loose": "Amplo"
    },
    "blockSpacing": {
      "tight": "Estreito",
      "slightlyTight": "Levemente estreito",
      "recommended": "Recomendado",
      "slightlyLoose": "Levemente amplo",
      "loose": "Amplo"
    },
    "linkColor": {
      "wechatBlue": {
        "label": "Azul do WeChat",
        "desc": "Padrão"
      },
      "primary": {
        "label": "Cor do tema",
        "desc": "Segue a cor do tema"
      },
      "body": {
        "label": "Cor do corpo",
        "desc": "Igual ao texto do corpo"
      }
    },
    "blockquoteBackground": {
      "theme": {
        "label": "Padrão do tema",
        "desc": "Padrão"
      },
      "none": {
        "label": "Nenhum",
        "desc": "Transparente"
      },
      "primary": {
        "label": "Cor do tema",
        "desc": "Tingido com a cor do tema"
      }
    },
    "color": {
      "classicBlue": {
        "label": "Azul",
        "desc": ""
      },
      "emeraldGreen": {
        "label": "Esmeralda",
        "desc": ""
      },
      "vividOrange": {
        "label": "Laranja",
        "desc": ""
      },
      "lemonYellow": {
        "label": "Amarelo",
        "desc": ""
      },
      "lavenderPurple": {
        "label": "Roxo",
        "desc": ""
      },
      "skyBlue": {
        "label": "Céu",
        "desc": ""
      },
      "roseGold": {
        "label": "Rosa",
        "desc": ""
      },
      "oliveGreen": {
        "label": "Olive",
        "desc": ""
      },
      "graphiteBlack": {
        "label": "Preto",
        "desc": ""
      },
      "mistGray": {
        "label": "Cinza",
        "desc": ""
      },
      "sakuraPink": {
        "label": "Rosa",
        "desc": ""
      }
    },
    "headingLevel": {
      "h1": "H1",
      "h2": "H2",
      "h3": "H3",
      "h4": "H4",
      "h5": "H5",
      "h6": "H6"
    },
    "headingStyle": {
      "default": "Padrão",
      "colorOnly": "Cor do texto",
      "borderBottom": "Linha inferior",
      "borderLeft": "Linha à esquerda",
      "custom": "Personalizado"
    },
    "legend": {
      "titleAlt": "título primeiro",
      "altTitle": "alt primeiro",
      "titleOnly": "título",
      "altOnly": "alt",
      "filename": "Arquivo",
      "none": "Nenhum"
    }
  }
}
