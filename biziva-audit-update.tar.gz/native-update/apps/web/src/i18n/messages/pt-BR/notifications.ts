// Biziva Brazilian Portuguese locale; original keys and placeholders preserved.
export default {
  "notifications": {
    "title": "Notificações",
    "empty": "Nenhuma notificação ainda",
    "markAllRead": "Marcar tudo como lido",
    "clearAll": "Limpar tudo",
    "clearAllConfirm": "Limpar todas as notificações? Esta ação não pode ser desfeita.",
    "unreadBadge": "{count} não lidas",
    "pending": "“{name}” está aguardando revisão",
    "approved": "“{name}” foi aprovado",
    "rejected": "“{name}” foi rejeitado",
    "rejectedWithReason": "“{name}” foi rejeitado: {reason}"
  }
}
