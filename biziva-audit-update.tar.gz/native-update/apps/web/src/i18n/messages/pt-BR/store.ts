// Biziva Brazilian Portuguese locale; original keys and placeholders preserved.
export default {
  "store": {
    "editor": {
      "contentCleared": "Conteúdo limpo",
      "contentReset": "Conteúdo redefinido"
    },
    "post": {
      "defaultTitle": "Conteúdo 1"
    },
    "template": {
      "created": "Template \"{name}\" criado",
      "notFound": "Template não encontrado",
      "updated": "Template atualizado",
      "deleted": "Template \"{name}\" excluído",
      "batchDeleted": "{count} template(s) excluídos",
      "allCleared": "Todos os templates foram limpos ({count} no total)",
      "importInvalidFormat": "Falha ao importar: formato de dados inválido",
      "importNoValid": "Falha ao importar: nenhum dado de template válido",
      "importSuccess": "{count} template(s) importados com sucesso",
      "importParseError": "Falha ao importar: erro ao analisar dados"
    },
    "component": {
      "created": "Componente \"{name}\" criado",
      "notFound": "Componente não encontrado",
      "updated": "Componente atualizado",
      "deleted": "Componente \"{name}\" excluído"
    },
    "cssEditor": {
      "schemeDefault": "Esquema 1",
      "schemeDefaultSpaced": "Esquema 1",
      "keepAtLeastOne": "Mantenha pelo menos um esquema",
      "batchDeleted": "{count} esquema(s) excluído(s)",
      "batchExported": "{count} esquema(s) exportado(s)",
      "singleExported": "\"{name}\" exportado"
    },
    "folder": {
      "apiNotSupported": "Seu navegador não oferece suporte à API File System Access",
      "permissionDenied": "A permissão de acesso à pasta não foi concedida",
      "opened": "Pasta \"{name}\" aberta",
      "openFailed": "Falha ao abrir a pasta: {message}",
      "noFolderSelected": "Nenhuma pasta selecionada",
      "fileNotFound": "Arquivo não encontrado: {path}",
      "notAFile": "Não é um arquivo: {path}",
      "readFailed": "Falha ao ler o arquivo: {message}"
    },
    "mpAccount": {
      "newAccount": "Nova conta",
      "officialAccount": "Conta Oficial",
      "serviceAccount": "Conta de Serviço"
    },
    "sync": {
      "syncing": "Sincronizando",
      "syncingHint": "Trocando dados com a nuvem…",
      "synced": "Sincronizado",
      "syncedHint": "O conteúdo local corresponde ao da nuvem",
      "failed": "Falha na sincronização",
      "failedHintDetail": "Falha na sincronização. Veja os detalhes abaixo",
      "retryLater": "Tente novamente mais tarde",
      "pending": "Sincronização pendente",
      "pendingHint": "Alterações locais ainda não enviadas",
      "syncingTooltip": "Sincronizando…",
      "syncedTooltip": "Sincronizado",
      "failedTooltip": "Falha na sincronização. Clique para tentar novamente",
      "pendingTooltip": "Alterações não sincronizadas",
      "rateLimited": "Limite de sincronização atingido. Tente novamente mais tarde",
      "quotaExceeded": "Limite de documentos na nuvem atingido. Exclua alguns posts ou faça upgrade para o Pro e sincronize novamente",
      "payloadTooLarge": "O pacote de sincronização é muito grande. Encurte alguns posts e tente novamente"
    },
    "uploader": {
      "fileReadFailed": "Falha ao ler o arquivo",
      "fileReadError": "Erro ao ler o arquivo",
      "corsFailed": "Falha na solicitação de origem cruzada: a imagem bloqueia o CORS e o proxy não conseguiu buscá-la.",
      "downloadFailed": "Falha no download da imagem: {message}",
      "uploadFailed": "Falha no envio",
      "defaultHostRequiresApi": "O host de imagem padrão requer a configuração do serviço de upload md-api"
    },
    "pdf": {
      "pageFooter": "Página \" counter(page) \" de \" counter(pages) \"",
      "pageFooterN": "\" counter(page) \""
    },
    "png": {
      "segmentsStart": "Preparando imagens longas…",
      "segmentsProgress": "Exportando imagem {done} de {total}…",
      "segmentsDone": "{count} imagens exportadas",
      "segmentsEmpty": "Nada para exportar",
      "segmentsFailed": "Falha na exportação da imagem longa: {message}"
    },
    "relativeTime": {
      "justNow": "Agora mesmo",
      "secondsAgo": "há {seconds}s",
      "minutesAgo": "há {minutes}min",
      "hoursAgo": "há {hours}h",
      "daysAgo": "há {days}d"
    },
    "diagram": {
      "downloadSvg": "Baixar como SVG",
      "downloadPng": "Baixar como PNG",
      "mermaidLoading": "Carregando Mermaid…",
      "mermaidError": "Falha na renderização do Mermaid: {detail}",
      "plantumlLoading": "Carregando diagrama PlantUML…",
      "plantumlError": "Falha ao carregar o diagrama PlantUML",
      "infographicLoading": "Carregando infográfico…",
      "infographicError": "Falha na renderização do infográfico: {detail}"
    },
    "count": {
      "summary": "{words} palavras, cerca de {minutes} min de leitura"
    },
    "render": {
      "footnoteTitle": "Referências",
      "unknownComponent": "Componente desconhecido: {name}",
      "katexLoading": "Carregando fórmula…",
      "renderFailed": "Falha na renderização"
    },
    "popup": {
      "mustRead": "Antes de começar",
      "mpHostIntro": "Para usar a biblioteca de mídia da Conta Oficial do WeChat como host de imagens, conclua a seguinte configuração:",
      "step1": "1. Ative o modo desenvolvedor para sua Conta Oficial",
      "viewDocs": "Ver documentação",
      "step2": "2. Configure a lista de IPs permitidos",
      "tutorial": "Tutorial",
      "getStarted": "Começar"
    },
    "passwordInput": {
      "toggleVisibility": "Alternar visibilidade da senha"
    },
    "extension": {
      "editorTitle": "Editor Markdown para WeChat"
    },
    "afdian": {
      "monthly": "Mensal",
      "quarterly": "Trimestral",
      "yearly": "Anual"
    },
    "emoji": {
      "title": "Emoji",
      "defaultPack": "Embutido",
      "myPack": "Meus emojis",
      "uploadedCount": "{n} emojis enviados",
      "uploadIncomplete": "Alguns emojis não puderam ser enviados. Tente novamente",
      "requestFailed": "A operação falhou. Tente novamente",
      "quotaReached": "Cada usuário pode salvar até {n} emojis",
      "invalidFiles": "Use imagens PNG, JPG, GIF ou WebP de até 5 MB",
      "clearPack": "Limpar meus emojis",
      "clearPackConfirm": "Limpar todos os emojis em \"{name}\"?",
      "packCleared": "Seus emojis foram limpos",
      "loginTitle": "Entre para salvar seus emojis",
      "loginHint": "Use o mesmo pacote de emojis em navegadores e dispositivos após entrar.",
      "loginAction": "Entrar",
      "loadFailed": "Falha ao carregar emojis",
      "retry": "Tentar novamente",
      "userEmpty": "Ainda não há emojis personalizados",
      "defaultEmpty": "Os emojis integrados ainda não estão disponíveis",
      "cloudUnavailable": "Emojis na nuvem não estão configurados neste ambiente",
      "addEmoji": "Adicionar emoji",
      "deleteEmoji": "Excluir emoji",
      "deleteEmojiConfirm": "Excluir o emoji \"{name}\"?",
      "emojiDeleted": "Emoji excluído",
      "renamePack": "Renomear pacote de emojis",
      "packRenamed": "Pacote de emojis renomeado",
      "addToPack": "Adicionar emoji a este pacote",
      "searchPlaceholder": "Pesquisar nome, pinyin ou shortcode",
      "noResults": "Nenhum emoji correspondente",
      "searchResults": "Resultados da pesquisa",
      "mode": {
        "small": "Pequeno",
        "original": "Original"
      },
      "alignCycle": "Clique para alterar o alinhamento",
      "align": {
        "left": "Esquerda",
        "center": "Centro",
        "right": "Direita"
      },
      "count": "{n}",
      "builtIn": {
        "title": "Emoji"
      }
    }
  }
}
